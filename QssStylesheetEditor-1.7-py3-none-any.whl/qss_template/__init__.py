# -*- coding: utf-8 -*-
"""parser for qss

Copyright (c) 2019 lileilei <hustlei@sina.cn>
"""

from .qsst import Qsst

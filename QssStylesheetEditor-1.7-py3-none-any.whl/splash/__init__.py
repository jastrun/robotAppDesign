# -*- coding: utf-8 -*-
"""SplashScreen

Show splash, preload modules and show progress in splashscreen

Copyright (c) 2019 lileilei <hustlei@sina.cn>
"""

from .splash import SplashScreen

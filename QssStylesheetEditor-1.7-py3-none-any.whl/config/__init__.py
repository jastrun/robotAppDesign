# -*- coding: utf-8 -*-
"""config and setting dialog for program

Copyright (c) 2019 lileilei. <hustlei@sina.cn>
"""

from config import core, dialog

Config = core.Config
ConfDialog = dialog.ConfDialog
